class utilisateur:
    def __init__(self, nom, age, email, mot_de_passe, genre):
        self.nom = nom
        self.age = age
        self.genre=genre
        self.email = email
        self.mot_de_passe = mot_de_passe
class professeur(utilisateur):
    def __init__(self,ppr,grade):
        utilisateur.__init__(self,ppr,grade)
        self.ppr = ppr
        self.grade = grade
class module:
    def __init_(self,nom,volume,semestre):
         self.nom=nom
         self.volume=volume
         self.semestre=semestre

class etudiant(utilisateur):
    def __init__(self,code_massar):
        utilisateur.__init__(self)
        self.code_massar=code_massar

class matiere:
    def __init__(self,nom,percentage):
        self.nom=nom
        self.percentage=percentage
class evaluation:
    def __init__(self,note):
        self.note=note
class anne_academique:
    def __init__(self,annee):
        self.annee=annee