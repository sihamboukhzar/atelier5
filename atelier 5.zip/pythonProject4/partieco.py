class Etudiant:
    def __init__(self, prenom,nom, age, cne,moyenne):
        self.prenom = prenom
        self.nom = nom
        self.age = age
        self.cne= cne
        self.moyenne=moyenne
Etudiant1 = Etudiant('siham','boukhzar', 22, 'k13556838',18)
Etudiant2 = Etudiant('malak','njari', 34,'lb5568356',14)
Etudiant3= Etudiant('najlae', 'flifla',20,'m78643679',12)
Etudiant4= Etudiant('manal', 'charki',21,'j08564631',17)
liste = [Etudiant1, Etudiant2, Etudiant3, Etudiant4]
print('voici la liste trie selon l age:')
liste.sort(key=lambda x: x.age)
print([item.nom for item in liste])
liste.sort(key=lambda x: x.moyenne)
print("voici la liste trie selon la moyenne:")
print([item.nom  for item in liste])