
class Vecteur2d: # la definition de la class Vecteur2d
     def __init__(self,x ,y):#la definition de la Constructeur parametree
             self.x = x
             self.y = y
     def display(self):
        print("les cordonnees sont : \n * x :%d \n * y: %d" % (self.x, self.y))
class VEcteur2d(Vecteur2d):
        def __init__(self,x,y):
                "Constructeur avec valeur par defaut"
                Vecteur2d.__init__(self,x,y)
                self.nom = "carre"
        def display(self):
            print("les cordonnees sont : \n * x :%d \n * y: %d" % (self.x, self.y))
vect = Vecteur2d(0,0)# initialiser le constrecteur
vect.display()
vecteur = VEcteur2d(5,9)
vecteur.display()
