class Point:
    """classe des points du plan."""

    def __init__(self, x=0.0, y=0.0):
        "Initialisation avec valeurs par defaut"
        self.px = float(x)
        self.py = float(y)
class Segment:
    """classe composite utilisant la classe Point."""

    def __init__(self, x1, y1, x2, y2):
        "L'initialisation utilise deux objets Point"
        self.orig = Point(x1, y1)
        self.extrem = Point(x2, y2)

    def show(self):
        print("\nSegment : [(%d, %d), (%d, %d)]" % (self.orig.px, self.orig.py, self.extrem.px, self.extrem.py))

# Auto-test ---------------------------------------------------------
s = Segment(1, 2, 3, 4)
s.show()