class Vecteur2d :# la definition de la class Vecteur2d
  def __init__(self,y): # la definition de la Constructeur parametree
     self.y = y
  def add(self, vect1, vect2):
    vect1 = Vecteur2d(self.y)
    vect2 = Vecteur2d(self.y)
    return (vect1.y + vect2.y)
vect1 = Vecteur2d(5)
vect2 = Vecteur2d(1)
vect=Vecteur2d(10)
print ("l'addition est ",vect.add(vect1,vect2))